
  # Carbon-Aware Production Scheduler

  This is a code bundle for Carbon-Aware Production Scheduler. The original project is available at https://www.figma.com/design/2a26NzgW8OCcAvaaTnU4da/Carbon-Aware-Production-Scheduler.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  