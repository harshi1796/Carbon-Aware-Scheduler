import { Link } from "react-router";
import { Button } from "./ui/button";
import { ArrowRight, TrendingDown, Factory, Leaf, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-50 to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Carbon-Aware Production Scheduler
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Schedule industrial production when electricity is cleanest to
                reduce carbon emissions and energy costs.
              </p>
              <div className="flex gap-4">
                <Link to="/scheduler">
                  <Button size="lg" className="bg-green-600 hover:bg-green-700">
                    Try Scheduler
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button size="lg" variant="outline">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1766246719951-0d21674dd9b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmFjdG9yeSUyMHN1c3RhaW5hYmlsaXR5JTIwZ3JlZW4lMjBlbmVyZ3l8ZW58MXx8fHwxNzczMjQzOTkzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Industrial factory with green energy"
                className="w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Problem Statement Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              The Problem We're Solving
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Factories run machines regardless of electricity carbon intensity.
              This leads to unnecessary CO₂ emissions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-8">
              <Factory className="w-12 h-12 text-red-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Current Problem
              </h3>
              <p className="text-gray-600 mb-4">
                Electricity carbon intensity changes throughout the day depending
                on energy sources (coal, solar, wind, etc.). Most factories
                operate on fixed schedules without considering these variations.
              </p>
              <div className="bg-white rounded-lg p-4 border border-red-300">
                <div className="text-sm text-gray-600">Morning (8 AM):</div>
                <div className="text-2xl font-bold text-red-600">
                  450 gCO₂/kWh
                </div>
                <div className="text-xs text-gray-500">Coal-heavy grid</div>
              </div>
            </div>

            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-8">
              <Leaf className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Our Solution
              </h3>
              <p className="text-gray-600 mb-4">
                Our solution helps industries schedule production when the
                electricity grid is cleanest, dramatically reducing emissions
                without changing operations.
              </p>
              <div className="bg-white rounded-lg p-4 border border-green-300">
                <div className="text-sm text-gray-600">Afternoon (3 PM):</div>
                <div className="text-2xl font-bold text-green-600">
                  210 gCO₂/kWh
                </div>
                <div className="text-xs text-gray-500">Solar-powered grid</div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white border border-gray-200 rounded-xl p-6 text-center shadow-sm">
              <div className="text-4xl font-bold text-blue-600 mb-2">24%</div>
              <div className="text-gray-600">
                Industry contributes to global CO₂ emissions
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-xl p-6 text-center shadow-sm">
              <div className="text-4xl font-bold text-green-600 mb-2">20%</div>
              <div className="text-gray-600">
                Potential emission reduction through smart scheduling
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-xl p-6 text-center shadow-sm">
              <div className="text-4xl font-bold text-purple-600 mb-2">53%</div>
              <div className="text-gray-600">
                Average carbon intensity variation during the day
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600">
              Three simple steps to reduce your carbon footprint
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Enter Production Details
              </h3>
              <p className="text-gray-600">
                Input your batch name, energy requirements, duration, and
                deadline into our scheduler tool.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl font-bold text-green-600">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                AI Analyzes Carbon Data
              </h3>
              <p className="text-gray-600">
                Our algorithm analyzes hourly carbon intensity data to find the
                optimal production window.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl font-bold text-purple-600">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Get Optimized Schedule
              </h3>
              <p className="text-gray-600">
                Receive your optimal production schedule with detailed emission
                savings and environmental impact.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Reduce Your Carbon Footprint?
          </h2>
          <p className="text-xl text-green-50 mb-8">
            Start scheduling smarter today and make a real impact on the
            environment.
          </p>
          <Link to="/scheduler">
            <Button
              size="lg"
              className="bg-white text-green-600 hover:bg-gray-100"
            >
              Get Started Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}