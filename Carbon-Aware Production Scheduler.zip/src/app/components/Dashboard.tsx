import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Area,
  AreaChart,
} from "recharts";
import { carbonIntensityData } from "../data/carbonData";
import { TrendingDown, Zap, Wind, Sun, Factory } from "lucide-react";

export function Dashboard() {
  const currentHour = new Date().getHours();
  const currentIntensity = carbonIntensityData[currentHour];

  const getSourceIcon = (source: string) => {
    switch (source.toLowerCase()) {
      case "solar":
        return <Sun className="w-4 h-4 text-yellow-500" />;
      case "wind":
        return <Wind className="w-4 h-4 text-blue-500" />;
      case "coal":
        return <Factory className="w-4 h-4 text-gray-600" />;
      default:
        return <Zap className="w-4 h-4 text-purple-500" />;
    }
  };

  const getIntensityColor = (intensity: number) => {
    if (intensity < 250) return "text-green-600";
    if (intensity < 350) return "text-yellow-600";
    return "text-red-600";
  };

  const getIntensityLabel = (intensity: number) => {
    if (intensity < 250) return "Low";
    if (intensity < 350) return "Moderate";
    return "High";
  };

  const avgIntensity =
    carbonIntensityData.reduce((sum, d) => sum + d.intensity, 0) /
    carbonIntensityData.length;
  const minIntensity = Math.min(...carbonIntensityData.map((d) => d.intensity));
  const maxIntensity = Math.max(...carbonIntensityData.map((d) => d.intensity));

  return (
    <div className="py-8 md:py-12 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 md:mb-12 bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-xl shadow-md border-2 border-blue-200">
          <h1 className="text-3xl md:text-4xl font-bold text-black mb-3">
            Carbon Dashboard
          </h1>
          <p className="text-lg md:text-xl text-black">
            Real-time carbon intensity analytics and insights
          </p>
        </div>

        {/* Current Status Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 mb-8">
          <Card className="bg-white shadow-md border-2 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs md:text-sm font-medium text-black">
                Current Intensity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span
                  className={`text-2xl md:text-3xl font-bold ${getIntensityColor(
                    currentIntensity.intensity
                  )}`}
                >
                  {currentIntensity.intensity}
                </span>
                <span className="text-black mb-1 text-xs md:text-base">gCO₂/kWh</span>
              </div>
              <div className="flex items-center gap-1 mt-2">
                {getSourceIcon(currentIntensity.source)}
                <span className="text-xs md:text-sm text-black">
                  {currentIntensity.source}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md border-2 border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs md:text-sm font-medium text-black">
                Today's Average
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className="text-2xl md:text-3xl font-bold text-black">
                  {Math.round(avgIntensity)}
                </span>
                <span className="text-black mb-1 text-xs md:text-base">gCO₂/kWh</span>
              </div>
              <div className="text-xs md:text-sm text-black mt-2">
                {getIntensityLabel(avgIntensity)} intensity
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md border-2 border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs md:text-sm font-medium text-black">
                Minimum Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className="text-2xl md:text-3xl font-bold text-green-600">
                  {minIntensity}
                </span>
                <span className="text-black mb-1 text-xs md:text-base">gCO₂/kWh</span>
              </div>
              <div className="text-xs md:text-sm text-black mt-2">
                Best time: 3 PM (Solar)
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md border-2 border-red-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs md:text-sm font-medium text-black">
                Maximum Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className="text-2xl md:text-3xl font-bold text-red-600">
                  {maxIntensity}
                </span>
                <span className="text-black mb-1 text-xs md:text-base">gCO₂/kWh</span>
              </div>
              <div className="text-xs md:text-sm text-black mt-2">
                Peak time: 8 AM (Coal)
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Carbon Intensity Chart */}
        <Card className="mb-8 bg-white shadow-lg border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-black">24-Hour Carbon Intensity</CardTitle>
            <p className="text-sm text-black">
              Carbon intensity throughout the day (gCO₂/kWh)
            </p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={carbonIntensityData}>
                <defs>
                  <linearGradient id="colorIntensity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" />
                <XAxis dataKey="time" tick={{ fill: '#000000' }} />
                <YAxis label={{ value: "gCO₂/kWh", angle: -90, position: "insideLeft", fill: '#000000' }} tick={{ fill: '#000000' }} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-3 rounded-lg shadow-lg border-2 border-gray-300">
                          <div className="font-semibold text-black">{data.time}</div>
                          <div className="text-sm text-black">
                            Intensity: {data.intensity} gCO₂/kWh
                          </div>
                          <div className="flex items-center gap-1 text-sm">
                            {getSourceIcon(data.source)}
                            <span className="text-black">{data.source}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="intensity"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorIntensity)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Energy Source Distribution */}
        <div className="grid lg:grid-cols-2 gap-6 md:gap-8">
          <Card className="bg-white shadow-lg border-2 border-blue-200">
            <CardHeader>
              <CardTitle className="text-black">Hourly Comparison</CardTitle>
              <p className="text-sm text-black">
                Carbon intensity by hour of day
              </p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={carbonIntensityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" />
                  <XAxis dataKey="time" tick={{ fill: '#000000' }} />
                  <YAxis tick={{ fill: '#000000' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#fff', border: '2px solid #cbd5e1' }} />
                  <Bar
                    dataKey="intensity"
                    fill="#3b82f6"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-lg border-2 border-green-200">
            <CardHeader>
              <CardTitle className="text-black">Optimal Production Windows</CardTitle>
              <p className="text-sm text-black">
                Best times to schedule production
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 md:space-y-4">
                {carbonIntensityData
                  .filter((d) => d.intensity < 280)
                  .map((data) => (
                    <div
                      key={data.hour}
                      className="flex items-center justify-between p-3 bg-green-50 rounded-lg border-2 border-green-300 shadow-sm"
                    >
                      <div className="flex items-center gap-2 md:gap-3">
                        {getSourceIcon(data.source)}
                        <div>
                          <div className="font-semibold text-black text-sm md:text-base">
                            {data.time}
                          </div>
                          <div className="text-xs md:text-sm text-black">
                            {data.source} energy
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-600 text-sm md:text-base">
                          {data.intensity}
                        </div>
                        <div className="text-xs text-black">gCO₂/kWh</div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Insights */}
        <Card className="mt-8 bg-gradient-to-r from-blue-100 to-green-100 border-2 border-blue-300 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-black">
              <TrendingDown className="w-5 h-5 text-blue-600" />
              Key Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sun className="w-5 h-5 text-yellow-500" />
                  <span className="font-semibold text-black">
                    Solar Peak
                  </span>
                </div>
                <p className="text-sm text-black">
                  12 PM - 4 PM has the lowest carbon intensity due to solar
                  energy production
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Factory className="w-5 h-5 text-gray-600" />
                  <span className="font-semibold text-black">
                    Avoid Morning
                  </span>
                </div>
                <p className="text-sm text-black">
                  7 AM - 9 AM has high carbon intensity from coal-powered grids
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Wind className="w-5 h-5 text-blue-500" />
                  <span className="font-semibold text-black">
                    Night Wind
                  </span>
                </div>
                <p className="text-sm text-black">
                  4 AM - 6 AM benefits from wind energy with lower intensity
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}