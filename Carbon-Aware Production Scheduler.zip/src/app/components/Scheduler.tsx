import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  ProductionBatch,
  ScheduleResult,
  findOptimalSchedule,
  carbonIntensityData,
} from "../data/carbonData";
import {
  Calendar,
  Clock,
  Zap,
  TrendingDown,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router";

export function Scheduler() {
  const [batchName, setBatchName] = useState("");
  const [energyRequired, setEnergyRequired] = useState("");
  const [duration, setDuration] = useState("");
  const [deadline, setDeadline] = useState("18");
  const [result, setResult] = useState<ScheduleResult | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const batch: ProductionBatch = {
      batchName,
      energyRequired: parseFloat(energyRequired),
      duration: parseFloat(duration),
      deadline: parseInt(deadline),
    };

    const schedule = findOptimalSchedule(batch);
    setResult(schedule);
  };

  const isFormValid =
    batchName.trim() &&
    energyRequired &&
    parseFloat(energyRequired) > 0 &&
    duration &&
    parseFloat(duration) > 0;

  return (
    <div className="py-12 bg-gradient-to-br from-green-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Production Scheduler Tool
          </h1>
          <p className="text-xl text-gray-700 max-w-2xl mx-auto">
            Enter your production batch details and we'll find the optimal time
            to minimize carbon emissions.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card className="shadow-lg bg-white">
            <CardHeader>
              <CardTitle className="text-black">Production Batch Details</CardTitle>
              <CardDescription className="text-gray-700">
                Fill in the information about your production batch
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="batchName" className="text-black">Batch Name</Label>
                  <Input
                    id="batchName"
                    placeholder="e.g., Steel Casting"
                    value={batchName}
                    onChange={(e) => setBatchName(e.target.value)}
                    className="mt-1 bg-white text-black border-gray-300"
                  />
                </div>

                <div>
                  <Label htmlFor="energy" className="text-black">Energy Required (kWh)</Label>
                  <div className="relative mt-1">
                    <Input
                      id="energy"
                      type="number"
                      placeholder="500"
                      value={energyRequired}
                      onChange={(e) => setEnergyRequired(e.target.value)}
                      min="1"
                      className="bg-white text-black border-gray-300"
                    />
                    <Zap className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="duration" className="text-black">Production Duration (hours)</Label>
                  <div className="relative mt-1">
                    <Input
                      id="duration"
                      type="number"
                      placeholder="3"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      min="1"
                      max="12"
                      className="bg-white text-black border-gray-300"
                    />
                    <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="deadline" className="text-black">Deadline</Label>
                  <Select value={deadline} onValueChange={setDeadline}>
                    <SelectTrigger className="mt-1 bg-white text-black border-gray-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {carbonIntensityData.map((data) => (
                        <SelectItem key={data.hour} value={data.hour.toString()}>
                          {data.time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                  disabled={!isFormValid}
                >
                  Generate Optimal Schedule
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </form>

              {/* Example */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-sm font-semibold text-blue-900 mb-2">
                  Example Input:
                </div>
                <div className="text-sm text-blue-700 space-y-1">
                  <div>Batch Name: Steel Casting</div>
                  <div>Energy: 500 kWh</div>
                  <div>Duration: 3 hours</div>
                  <div>Deadline: 6 PM</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          {result ? (
            <div className="space-y-6">
              <Card className="bg-white border border-green-300 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                    <CardTitle className="text-gray-900">
                      Optimal Schedule Found
                    </CardTitle>
                  </div>
                  <CardDescription className="text-gray-700">
                    Best production time: {result.optimalStartTime} –{" "}
                    {result.optimalEndTime}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="text-sm text-gray-700 mb-1">
                        Start Time
                      </div>
                      <div className="text-2xl font-bold text-black">
                        {result.optimalStartTime}
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="text-sm text-gray-700 mb-1">End Time</div>
                      <div className="text-2xl font-bold text-black">
                        {result.optimalEndTime}
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <div className="text-sm text-gray-700 mb-1">
                      Carbon Intensity
                    </div>
                    <div className="text-3xl font-bold text-green-600">
                      {result.carbonIntensity} gCO₂/kWh
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <div className="text-sm text-gray-700 mb-1">
                      Estimated Emissions
                    </div>
                    <div className="text-3xl font-bold text-black">
                      {result.totalEmissions} kg CO₂
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-blue-300 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-black">
                    <TrendingDown className="w-5 h-5 text-blue-600" />
                    Emission Reduction
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <span className="text-gray-700">Running Now:</span>
                      <span className="text-lg font-semibold text-red-600">
                        {result.currentEmissions} kg CO₂
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <span className="text-gray-700">Optimized Schedule:</span>
                      <span className="text-lg font-semibold text-green-600">
                        {result.totalEmissions} kg CO₂
                      </span>
                    </div>
                    <div className="border-t-2 border-gray-200 pt-3 mt-3">
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-black">
                          CO₂ Saved:
                        </span>
                        <span className="text-2xl font-bold text-green-600">
                          {result.emissionsSaved} kg
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <div className="text-center">
                      <div className="text-sm text-gray-700 mb-1">
                        Emission Reduction
                      </div>
                      <div className="text-4xl font-bold text-green-600">
                        {result.percentageSaved}%
                      </div>
                    </div>
                  </div>

                  <Link to="/impact" state={{ co2Saved: result.emissionsSaved }}>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white" variant="default">
                      See Environmental Impact
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="flex items-center justify-center bg-white shadow-lg border border-gray-200">
              <CardContent className="text-center py-20">
                <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">
                  Fill in the form to generate your optimal production schedule
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}