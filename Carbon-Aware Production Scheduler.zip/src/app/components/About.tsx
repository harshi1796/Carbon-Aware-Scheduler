import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import {
  Factory,
  Server,
  Cpu,
  Zap,
  Wind,
  Building2,
  Target,
  Users,
  Lightbulb,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function About() {
  const applications = [
    {
      icon: Factory,
      title: "Manufacturing Plants",
      description:
        "Optimize production schedules in steel mills, aluminum foundries, and other energy-intensive manufacturing facilities.",
      savings: "15-25% emission reduction",
      color: "bg-blue-100 text-blue-600",
    },
    {
      icon: Server,
      title: "Data Centers",
      description:
        "Schedule computational workloads and batch processing during periods of clean energy availability.",
      savings: "10-20% emission reduction",
      color: "bg-purple-100 text-purple-600",
    },
    {
      icon: Cpu,
      title: "Smart Factories",
      description:
        "Integrate with Industry 4.0 systems to automatically adjust production based on carbon intensity forecasts.",
      savings: "20-30% emission reduction",
      color: "bg-green-100 text-green-600",
    },
    {
      icon: Zap,
      title: "EV Charging Stations",
      description:
        "Optimize fleet charging schedules to align with renewable energy peaks, reducing grid strain.",
      savings: "15-35% emission reduction",
      color: "bg-yellow-100 text-yellow-600",
    },
    {
      icon: Wind,
      title: "Renewable Energy Grids",
      description:
        "Balance demand with renewable supply by encouraging consumption during high renewable generation periods.",
      savings: "25-40% emission reduction",
      color: "bg-cyan-100 text-cyan-600",
    },
    {
      icon: Building2,
      title: "Commercial Buildings",
      description:
        "Schedule HVAC systems, water heating, and other energy-intensive operations during clean energy windows.",
      savings: "10-15% emission reduction",
      color: "bg-orange-100 text-orange-600",
    },
  ];

  const features = [
    {
      icon: Target,
      title: "Precision Scheduling",
      description:
        "Advanced algorithms analyze hourly carbon intensity data to find the optimal production window that minimizes emissions while meeting your deadlines.",
    },
    {
      icon: Lightbulb,
      title: "Smart Insights",
      description:
        "Receive actionable recommendations based on historical patterns, renewable energy forecasts, and grid conditions.",
    },
    {
      icon: Users,
      title: "Industry Expertise",
      description:
        "Built in collaboration with sustainability officers, energy analysts, and factory managers to meet real-world needs.",
    },
  ];

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            About Carbon-Aware Scheduling
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A data-driven approach to reducing industrial carbon emissions
            through intelligent production scheduling
          </p>
        </div>

        {/* Mission */}
        <Card className="mb-12 bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-200">
          <CardContent className="py-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Our Mission
                </h2>
                <p className="text-lg text-gray-700 mb-4">
                  If factories schedule production when electricity is cleanest,
                  global industrial emissions could drop significantly.
                </p>
                <p className="text-gray-600 mb-6">
                  This solution combines sustainability, data analytics,
                  optimization, and industrial impact to create a powerful tool
                  for environmental change.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">
                        Data-Driven Decisions
                      </div>
                      <div className="text-sm text-gray-600">
                        Real-time carbon intensity analysis
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">
                        Measurable Impact
                      </div>
                      <div className="text-sm text-gray-600">
                        Track emissions saved in real-world terms
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">
                        Easy Integration
                      </div>
                      <div className="text-sm text-gray-600">
                        No infrastructure changes required
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1769501378399-bbea7f5cfc94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMHdpbmQlMjB0dXJiaW5lcyUyMHJlbmV3YWJsZXxlbnwxfHx8fDE3NzMyNDM5OTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Solar panels and wind turbines"
                  className="w-full h-80 object-cover"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Features */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Key Features
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index}>
                  <CardHeader>
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-500 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle>{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Real-World Applications */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Real-World Applications
            </h2>
            <p className="text-xl text-gray-600">
              Industries and sectors that can benefit from carbon-aware
              scheduling
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {applications.map((app, index) => {
              const Icon = app.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 ${app.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="w-6 h-6" />
                      </div>
                    </div>
                    <CardTitle className="text-lg">{app.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4 text-sm">
                      {app.description}
                    </p>
                    <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                      <div className="text-xs text-gray-600 mb-1">
                        Potential Savings
                      </div>
                      <div className="font-semibold text-green-700">
                        {app.savings}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Target Users */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="text-2xl">Who Benefits?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Factory className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  Factory Managers
                </h3>
                <p className="text-sm text-gray-600">
                  Optimize production schedules while reducing costs
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  Production Planners
                </h3>
                <p className="text-sm text-gray-600">
                  Data-driven scheduling decisions for efficiency
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Lightbulb className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  Sustainability Officers
                </h3>
                <p className="text-sm text-gray-600">
                  Track and report emission reductions
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-8 h-8 text-yellow-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  Energy Analysts
                </h3>
                <p className="text-sm text-gray-600">
                  Analyze grid patterns and optimize usage
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Future Features */}
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardHeader>
            <CardTitle className="text-2xl">Future Enhancements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h3 className="font-semibold mb-2">
                  🤖 AI Prediction
                </h3>
                <p className="text-blue-50 text-sm">
                  Predict future carbon intensity using machine learning models
                  for better planning
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">
                  📅 Multi-Batch Scheduling
                </h3>
                <p className="text-blue-50 text-sm">
                  Optimize multiple production batches simultaneously for
                  maximum efficiency
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">
                  ☀️ Renewable Matching
                </h3>
                <p className="text-blue-50 text-sm">
                  Automatically align production with solar and wind energy
                  generation peaks
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
