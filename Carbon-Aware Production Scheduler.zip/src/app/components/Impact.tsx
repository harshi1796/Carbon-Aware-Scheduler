import { useState } from "react";
import { useLocation } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { calculateImpact } from "../data/carbonData";
import { TreeDeciduous, Car, Home, Leaf, TrendingDown } from "lucide-react";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Button } from "./ui/button";

export function Impact() {
  const location = useLocation();
  const initialCO2 = location.state?.co2Saved || 120;
  const [co2Saved, setCo2Saved] = useState(initialCO2.toString());

  const impact = calculateImpact(parseFloat(co2Saved) || 0);

  return (
    <div className="py-12 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Sustainability Impact
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Understand the real-world environmental impact of your emission
            reductions
          </p>
        </div>

        {/* CO2 Input */}
        <Card className="max-w-md mx-auto mb-12 bg-white border-2 border-gray-200 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50">
            <CardTitle className="text-center text-black">Calculate Your Impact</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="co2" className="text-black">CO₂ Emissions Saved (kg)</Label>
                <Input
                  id="co2"
                  type="number"
                  value={co2Saved}
                  onChange={(e) => setCo2Saved(e.target.value)}
                  min="0"
                  className="mt-1 bg-white text-black border-gray-300"
                />
              </div>
              <div className="bg-green-50 rounded-lg p-4 border-2 border-green-200 text-center">
                <div className="text-sm text-gray-700 mb-1">
                  Total CO₂ Saved
                </div>
                <div className="text-4xl font-bold text-green-600">
                  {co2Saved || 0} kg
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Impact Visualizations */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <Card className="bg-white border-2 border-green-200 shadow-lg">
            <CardHeader className="bg-gradient-to-br from-green-50 to-emerald-50">
              <div className="flex items-center justify-center mb-4">
                <div className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center">
                  <TreeDeciduous className="w-10 h-10 text-white" />
                </div>
              </div>
              <CardTitle className="text-center text-black">
                Trees Planted
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-6xl font-bold text-green-600 mb-2">
                  {impact.treesPlanted}
                </div>
                <p className="text-sm text-gray-700">
                  Equivalent to planting this many trees for one year
                </p>
              </div>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {Array.from({ length: Math.min(impact.treesPlanted, 20) }).map(
                  (_, i) => (
                    <TreeDeciduous key={i} className="w-6 h-6 text-green-600" />
                  )
                )}
                {impact.treesPlanted > 20 && (
                  <span className="text-green-600 font-semibold">
                    +{impact.treesPlanted - 20}
                  </span>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-2 border-blue-200 shadow-lg">
            <CardHeader className="bg-gradient-to-br from-blue-50 to-cyan-50">
              <div className="flex items-center justify-center mb-4">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center">
                  <Car className="w-10 h-10 text-white" />
                </div>
              </div>
              <CardTitle className="text-center text-black">
                Car Emissions Avoided
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-6xl font-bold text-blue-600 mb-2">
                  {impact.kmAvoided}
                </div>
                <div className="text-sm text-gray-700">kilometers</div>
                <p className="text-sm text-gray-700 mt-2">
                  Equivalent to avoiding this much car travel
                </p>
              </div>
              <div className="mt-6 bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="text-xs text-gray-600 mb-1">Distance equals</div>
                <div className="text-lg font-semibold text-gray-900">
                  {impact.kmAvoided > 1000
                    ? `${(impact.kmAvoided / 1000).toFixed(1)} × cross-country trips`
                    : `${Math.round(impact.kmAvoided / 50)} × daily commutes`}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-2 border-purple-200 shadow-lg">
            <CardHeader className="bg-gradient-to-br from-purple-50 to-pink-50">
              <div className="flex items-center justify-center mb-4">
                <div className="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center">
                  <Home className="w-10 h-10 text-white" />
                </div>
              </div>
              <CardTitle className="text-center text-black">
                Home Energy
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-6xl font-bold text-purple-600 mb-2">
                  {impact.homesEnergy}
                </div>
                <div className="text-sm text-gray-700">homes</div>
                <p className="text-sm text-gray-700 mt-2">
                  Equivalent to powering this many homes for a day
                </p>
              </div>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {Array.from({ length: Math.min(impact.homesEnergy, 15) }).map(
                  (_, i) => (
                    <Home key={i} className="w-6 h-6 text-purple-600" />
                  )
                )}
                {impact.homesEnergy > 15 && (
                  <span className="text-purple-600 font-semibold">
                    +{impact.homesEnergy - 15}
                  </span>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Additional Context */}
        <Card className="mb-12 bg-white border-2 border-gray-200 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-black">
              <Leaf className="w-6 h-6 text-green-600" />
              Understanding Your Impact
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">
                  Why This Matters
                </h3>
                <div className="space-y-3 text-gray-600">
                  <p>
                    Carbon emissions from industrial production contribute
                    significantly to climate change. By scheduling production
                    when the grid is powered by renewable sources, you're:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>Reducing fossil fuel dependency</li>
                    <li>Supporting renewable energy adoption</li>
                    <li>Lowering your carbon footprint</li>
                    <li>Contributing to climate goals</li>
                  </ul>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">
                  Scaling the Impact
                </h3>
                <div className="space-y-3">
                  <div className="bg-blue-50 rounded-lg p-4 border-2 border-blue-200">
                    <div className="font-semibold text-blue-900 mb-1">
                      Daily Operations
                    </div>
                    <p className="text-sm text-blue-700">
                      If you optimize 5 batches per day, you could save{" "}
                      <span className="font-bold">
                        {parseFloat(co2Saved) * 5} kg CO₂ daily
                      </span>
                    </p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4 border-2 border-green-200">
                    <div className="font-semibold text-green-900 mb-1">
                      Annual Impact
                    </div>
                    <p className="text-sm text-green-700">
                      Over a year, this equals{" "}
                      <span className="font-bold">
                        {Math.round((parseFloat(co2Saved) * 5 * 365) / 1000)}{" "}
                        tons CO₂
                      </span>{" "}
                      saved
                    </p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-4 border-2 border-purple-200">
                    <div className="font-semibold text-purple-900 mb-1">
                      Industry-Wide
                    </div>
                    <p className="text-sm text-purple-700">
                      If adopted across the industry, carbon-aware scheduling
                      could reduce global emissions by millions of tons
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <Card className="bg-gradient-to-r from-green-600 to-emerald-600 text-white border-2 border-green-700 shadow-lg">
          <CardContent className="py-12 text-center">
            <TrendingDown className="w-16 h-16 mx-auto mb-4 opacity-90" />
            <h2 className="text-3xl font-bold mb-4">
              Every Kilogram Counts
            </h2>
            <p className="text-xl text-green-50 max-w-2xl mx-auto mb-6">
              Small changes in scheduling can lead to significant environmental
              benefits. Start optimizing your production today.
            </p>
            <div className="flex gap-4 justify-center">
              <a href="/scheduler">
                <Button
                  size="lg"
                  className="bg-white text-green-600 hover:bg-gray-100"
                >
                  Schedule Production
                </Button>
              </a>
              <a href="/dashboard">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-green-700"
                >
                  View Dashboard
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}