import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/Home";
import { Scheduler } from "./components/Scheduler";
import { Dashboard } from "./components/Dashboard";
import { Impact } from "./components/Impact";
import { About } from "./components/About";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "scheduler", Component: Scheduler },
      { path: "dashboard", Component: Dashboard },
      { path: "impact", Component: Impact },
      { path: "about", Component: About },
    ],
  },
]);
