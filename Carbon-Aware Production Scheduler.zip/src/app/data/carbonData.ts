// Mock carbon intensity data for a typical day (hourly data)
export interface CarbonIntensityData {
  hour: number;
  time: string;
  intensity: number; // gCO₂/kWh
  source: string;
}

export const carbonIntensityData: CarbonIntensityData[] = [
  { hour: 0, time: "12 AM", intensity: 380, source: "Mixed" },
  { hour: 1, time: "1 AM", intensity: 360, source: "Mixed" },
  { hour: 2, time: "2 AM", intensity: 340, source: "Mixed" },
  { hour: 3, time: "3 AM", intensity: 330, source: "Mixed" },
  { hour: 4, time: "4 AM", intensity: 320, source: "Wind" },
  { hour: 5, time: "5 AM", intensity: 310, source: "Wind" },
  { hour: 6, time: "6 AM", intensity: 350, source: "Mixed" },
  { hour: 7, time: "7 AM", intensity: 420, source: "Coal" },
  { hour: 8, time: "8 AM", intensity: 450, source: "Coal" },
  { hour: 9, time: "9 AM", intensity: 410, source: "Mixed" },
  { hour: 10, time: "10 AM", intensity: 360, source: "Solar" },
  { hour: 11, time: "11 AM", intensity: 320, source: "Solar" },
  { hour: 12, time: "12 PM", intensity: 280, source: "Solar" },
  { hour: 13, time: "1 PM", intensity: 250, source: "Solar" },
  { hour: 14, time: "2 PM", intensity: 230, source: "Solar" },
  { hour: 15, time: "3 PM", intensity: 210, source: "Solar" },
  { hour: 16, time: "4 PM", intensity: 240, source: "Solar" },
  { hour: 17, time: "5 PM", intensity: 290, source: "Mixed" },
  { hour: 18, time: "6 PM", intensity: 380, source: "Mixed" },
  { hour: 19, time: "7 PM", intensity: 410, source: "Coal" },
  { hour: 20, time: "8 PM", intensity: 430, source: "Coal" },
  { hour: 21, time: "9 PM", intensity: 400, source: "Mixed" },
  { hour: 22, time: "10 PM", intensity: 370, source: "Mixed" },
  { hour: 23, time: "11 PM", intensity: 360, source: "Mixed" },
];

export interface ProductionBatch {
  batchName: string;
  energyRequired: number; // kWh
  duration: number; // hours
  deadline: number; // hour (0-23)
}

export interface ScheduleResult {
  optimalStartHour: number;
  optimalEndHour: number;
  optimalStartTime: string;
  optimalEndTime: string;
  carbonIntensity: number;
  totalEmissions: number;
  currentEmissions: number;
  emissionsSaved: number;
  percentageSaved: number;
}

export function findOptimalSchedule(batch: ProductionBatch): ScheduleResult {
  const currentHour = new Date().getHours();
  const { energyRequired, duration, deadline } = batch;

  // Calculate emissions if running now
  let currentIntensity = 0;
  for (let i = 0; i < duration; i++) {
    const hour = (currentHour + i) % 24;
    currentIntensity += carbonIntensityData[hour].intensity;
  }
  currentIntensity = currentIntensity / duration;
  const currentEmissions = (energyRequired * currentIntensity) / 1000; // Convert to kg

  // Find optimal time slot before deadline
  let bestStartHour = currentHour;
  let lowestIntensity = Infinity;

  const deadlineHour = deadline;
  const searchLimit = deadlineHour > currentHour ? deadlineHour : deadlineHour + 24;

  for (let start = currentHour; start <= searchLimit - duration; start++) {
    let avgIntensity = 0;
    for (let i = 0; i < duration; i++) {
      const hour = (start + i) % 24;
      avgIntensity += carbonIntensityData[hour].intensity;
    }
    avgIntensity = avgIntensity / duration;

    if (avgIntensity < lowestIntensity) {
      lowestIntensity = avgIntensity;
      bestStartHour = start % 24;
    }
  }

  const optimalEndHour = (bestStartHour + duration) % 24;
  const totalEmissions = (energyRequired * lowestIntensity) / 1000; // kg
  const emissionsSaved = currentEmissions - totalEmissions;
  const percentageSaved = (emissionsSaved / currentEmissions) * 100;

  return {
    optimalStartHour: bestStartHour,
    optimalEndHour: optimalEndHour,
    optimalStartTime: carbonIntensityData[bestStartHour].time,
    optimalEndTime: carbonIntensityData[optimalEndHour].time,
    carbonIntensity: Math.round(lowestIntensity),
    totalEmissions: Math.round(totalEmissions),
    currentEmissions: Math.round(currentEmissions),
    emissionsSaved: Math.round(emissionsSaved),
    percentageSaved: Math.round(percentageSaved),
  };
}

export function calculateImpact(co2Saved: number) {
  // Conversion factors
  const treesPlanted = Math.round(co2Saved / 20); // ~20kg CO2 per tree per year
  const kmAvoided = Math.round(co2Saved / 0.24); // ~0.24kg CO2 per km car
  const homesEnergy = Math.round(co2Saved / 12); // ~12kg CO2 per home per day

  return {
    treesPlanted,
    kmAvoided,
    homesEnergy,
  };
}
